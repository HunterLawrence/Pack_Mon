package packMon;

public class PackMonDriver {

	public static void main(String[] args) {
		System.out.println("HELLO WORLD");
	}

}
